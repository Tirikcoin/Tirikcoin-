# TIRIK Coin

A simple TypeScript script to create the TIRIK Coin SPL token on the Solana blockchain.

## Requirements

- Node.js
- Solana CLI
- Solana wallet with SOL
- `@solana/web3.js`
- `@solana/spl-token`

## Setup

```bash
npm install
```

## Run

```bash
ts-node src/create-token.ts
```
