import { Connection, Keypair, clusterApiUrl } from "@solana/web3.js";
import {
  createMint,
  getOrCreateAssociatedTokenAccount,
  mintTo,
} from "@solana/spl-token";
import * as fs from "fs";

(async () => {
  const connection = new Connection(clusterApiUrl("devnet"), "confirmed");
  const payer = Keypair.generate(); // Replace with your wallet if needed

  console.log("Requesting airdrop...");
  const airdropSig = await connection.requestAirdrop(payer.publicKey, 2e9);
  await connection.confirmTransaction(airdropSig);

  const mint = await createMint(
    connection,
    payer,
    payer.publicKey,
    null,
    9 // 9 decimals like SOL
  );

  const tokenAccount = await getOrCreateAssociatedTokenAccount(
    connection,
    payer,
    mint,
    payer.publicKey
  );

  await mintTo(
    connection,
    payer,
    mint,
    tokenAccount.address,
    payer,
    1_000_000_000_000_000_000n // 1 billion with 9 decimals
  );

  console.log("TIRIK Coin created!");
  console.log("Token Mint Address:", mint.toBase58());

  fs.writeFileSync(
    "tirik-token-info.json",
    JSON.stringify({
      token: mint.toBase58(),
      account: tokenAccount.address.toBase58(),
    }, null, 2)
  );
})();
